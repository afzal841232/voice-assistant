import os

import eel

from engine2.features2 import *
from engine2.command import *


def start():
    
    eel.init("vvvv")

    playAssistantSound()


    os.system('start msedge.exe --app="http://localhost:8000/index2.html"')

    eel.start('index2.html', mode=None, host='localhost', block=True)
