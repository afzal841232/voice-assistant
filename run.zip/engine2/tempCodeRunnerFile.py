
    except Exception as e:
        return ""

    return query.lower() 


text = takecommand()

speak(text)


